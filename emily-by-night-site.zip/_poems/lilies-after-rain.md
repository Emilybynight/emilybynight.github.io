---
title: Lilies, after rain
date: 2026-10-20
language: English
---
I keep the flowers my mother would have thrown away,
the ones bruised at the edges,
still opening anyway.

There is a kind of faith
in anything that blooms
after it has been told it is finished.
