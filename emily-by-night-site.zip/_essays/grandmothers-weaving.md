---
title: What my grandmother's weaving knew about policy
date: 2026-10-05
topic: Culture
excerpt: Example essay. On Amazigh craft, women's labour, and the knowledge that institutions forget to count.
---
This is an example essay so you can see the layout. Replace it with your own writing from the dashboard.

Essays support **bold**, *italics*, links, quotes and pictures.
